<script setup lang="ts">
import PagePlaceholder from '@/components/common/PagePlaceholder.vue'
</script>

<template>
  <PagePlaceholder description="运行日志：查看任务执行、AI 调用、第三方接口、营销推送与 CRM 同步的运行记录及失败详情。" />
</template>
