<script setup lang="ts">
import PagePlaceholder from '@/components/common/PagePlaceholder.vue'
</script>

<template>
  <PagePlaceholder description="商机详情：展示商机信息、归属业务员、孚盟 CRM 同步状态与重新同步，以及 CRM 回传的阶段流转。" />
</template>
