<script setup lang="ts">
import PagePlaceholder from '@/components/common/PagePlaceholder.vue'
</script>

<template>
  <PagePlaceholder description="商机列表：查看全部商机及其 CRM 同步状态与销售阶段，销售阶段以孚盟 CRM 回传为准；创建商机使用 Drawer。" />
</template>
