<script setup lang="ts">
import PagePlaceholder from '@/components/common/PagePlaceholder.vue'
</script>

<template>
  <PagePlaceholder description="待开发客户：展示 AI 有效企业中邮箱验证通过的可营销集合，以及自动推送营销系统的成功、失败、失败原因与重新推送。" />
</template>
