<script setup lang="ts">
import PagePlaceholder from '@/components/common/PagePlaceholder.vue'
</script>

<template>
  <PagePlaceholder description="正向客户：展示营销系统回传并落库的正向客户（inquiry / potential_interest），确认营销已停止，并完成系统推荐业务员 → 老板确认调配 → 正式分配。" />
</template>
