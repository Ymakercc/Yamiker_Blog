﻿<#
    新电脑一键设置脚本
    功能：1) 体检磁盘  2) 从 C 盘切出 D 盘  3) 在 D 盘建文件夹  4) 自动安装常用软件
    请通过同目录下的「一键设置.bat」运行（会自动申请管理员权限）
#>

$ProgressPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$LogFile = Join-Path $PSScriptRoot ("setup-log-{0}.txt" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))

function Log {
    param([string]$Msg, [string]$Color = 'Gray')
    $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $Msg
    Write-Host $line -ForegroundColor $Color
    try { Add-Content -Path $LogFile -Value $line -Encoding UTF8 } catch {}
}
function Title {
    param([string]$T)
    Write-Host ""
    Write-Host ("=" * 62) -ForegroundColor Cyan
    Write-Host ("  " + $T)                -ForegroundColor Cyan
    Write-Host ("=" * 62) -ForegroundColor Cyan
    try { Add-Content -Path $LogFile -Value ("`r`n===== $T =====") -Encoding UTF8 } catch {}
}
function ToGB { param($b) "{0:N1} GB" -f ($b / 1GB) }

# Win11 家庭版没有 Get-BitLockerVolume，改用 WMI / manage-bde 检测「设备加密」
function Test-CDriveEncrypted {
    try {
        $v = Get-CimInstance -Namespace 'root\CIMV2\Security\MicrosoftVolumeEncryption' `
                             -ClassName Win32_EncryptableVolume `
                             -Filter "DriveLetter='C:'" -ErrorAction Stop
        if ($v) { return ($v.ProtectionStatus -ne 0) }
    } catch {}
    try {
        $out = & manage-bde.exe -status C: 2>&1 | Out-String
        if ($out -match '保护已启用|Protection On') { return $true }
    } catch {}
    return $false
}

# ---------- 0. 管理员权限检查 ----------
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "请右键「一键设置.bat」-> 以管理员身份运行" -ForegroundColor Red
    Read-Host "按回车键退出"
    exit 1
}

Title "新电脑一键设置  开始"
Log ("系统: " + (Get-CimInstance Win32_OperatingSystem).Caption)
Log ("日志将保存到: " + $LogFile)

# ================================================================
#  第 1 步：磁盘体检
# ================================================================
Title "第 1 步 / 共 5 步：检查磁盘情况"

$canPartition = $false
$dReady       = $false
$partMsg      = ""

try {
    $cPart  = Get-Partition -DriveLetter C
    $cVol   = Get-Volume    -DriveLetter C
    $disk   = Get-Disk -Number $cPart.DiskNumber
    $usedC  = $cVol.Size - $cVol.SizeRemaining

    Log ("C 盘所在硬盘: 磁盘{0}  总容量 {1}  分区表 {2}" -f $disk.Number, (ToGB $disk.Size), $disk.PartitionStyle)
    Log ("C 盘: 总 {0}  已用 {1}  剩余 {2}" -f (ToGB $cVol.Size), (ToGB $usedC), (ToGB $cVol.SizeRemaining))

    Log "当前分区表："
    foreach ($p in (Get-Partition -DiskNumber $disk.Number | Sort-Object PartitionNumber)) {
        Log ("    分区{0}  {1,-16} {2,10}  盘符:{3}" -f $p.PartitionNumber, $p.Type, (ToGB $p.Size),
             $(if ($p.DriveLetter) { $p.DriveLetter } else { '无' }))
    }

    # --- D 盘符是否已被占用 ---
    $dVol = Get-Volume -DriveLetter D -ErrorAction SilentlyContinue

    if ($dVol -and $dVol.DriveType -eq 'Fixed') {
        $dReady  = $true
        $partMsg = "电脑已经有 D 盘了（$(ToGB $dVol.Size)），不需要重新分盘，直接使用。"
        Log $partMsg 'Green'
    }
    elseif ($dVol -and $dVol.DriveType -eq 'Removable') {
        $partMsg = "D 盘符被 U 盘 / 移动硬盘占用了。请拔掉后重新运行本脚本。"
        Log $partMsg 'Yellow'
    }
    else {
        if ($dVol -and $dVol.DriveType -eq 'CD-ROM') {
            Log "D 盘符被光驱占用，正在把光驱改成 Z 盘 ..." 'Yellow'
            Get-CimInstance -ClassName Win32_Volume -Filter "DriveLetter='D:'" |
                Set-CimInstance -Property @{ DriveLetter = 'Z:' }
            Start-Sleep -Seconds 2
            Log "光驱已改为 Z 盘。" 'Green'
        }

        # --- 是否有第二块硬盘（更适合直接做 D 盘，不动 C） ---
        $otherDisks = Get-Disk | Where-Object { $_.Number -ne $disk.Number -and $_.BusType -notin @('USB') }
        if ($otherDisks) {
            $partMsg = "检测到这台电脑有 " + ($otherDisks.Count + 1) + " 块硬盘。这种情况下直接切 C 盘不是最佳方案，" +
                       "脚本不会自动分盘，请让哥哥手动处理第二块硬盘。"
            Log $partMsg 'Yellow'
        }
        # --- BitLocker 检查 ---
        elseif (Test-CDriveEncrypted) {
            $partMsg = "C 盘开启了「设备加密 / BitLocker」，这种状态下无法调整分区大小。"
            Log $partMsg 'Yellow'
            Write-Host ""
            Write-Host "  ---------------- 需要你先做一件事 ----------------" -ForegroundColor Yellow
            Write-Host "  1. 我马上帮你打开「设备加密」设置页" -ForegroundColor White
            Write-Host "  2. 把那个开关关掉（会提示正在解密，等它跑完）" -ForegroundColor White
            Write-Host "  3. 解密需要 20~60 分钟，期间可以正常用电脑，但别关机" -ForegroundColor White
            Write-Host "  4. 完成后重新双击「一键设置.bat」即可" -ForegroundColor White
            Write-Host "  -------------------------------------------------" -ForegroundColor Yellow
            Write-Host ""
            $a = Read-Host "  按回车键打开设置页（输入 N 回车则跳过分盘，只装软件）"
            if ($a -notmatch '^[Nn]$') {
                try { Start-Process 'ms-settings:deviceencryption' } catch { Start-Process 'ms-settings:' }
                Log "已打开设备加密设置页。" 'Cyan'
            }
        }
        # --- MBR 四主分区限制 ---
        elseif ($disk.PartitionStyle -eq 'MBR' -and (Get-Partition -DiskNumber $disk.Number).Count -ge 4) {
            $partMsg = "这块硬盘是 MBR 格式且已有 4 个主分区，无法再新建分区。"
            Log $partMsg 'Yellow'
        }
        else {
            # --- 计算分盘方案 ---
            $supported = Get-PartitionSupportedSize -DriveLetter C

            # 按硬盘实际容量分档，给 C 盘留出够用的空间
            if     ($cPart.Size -ge 1700GB) { $baseC = 400GB }   # 2TB
            elseif ($cPart.Size -ge 850GB)  { $baseC = 280GB }   # 1TB
            elseif ($cPart.Size -ge 400GB)  { $baseC = 200GB }   # 512GB
            else                            { $baseC = 150GB }   # 256GB 或更小

            $keepC = [math]::Max($baseC, $usedC + 60GB)          # 至少要比已用空间多 60GB
            $keepC = [math]::Max($keepC, $supported.SizeMin)     # 不能小于系统允许的最小值
            $keepC = [math]::Min($keepC, $cPart.Size)
            $keepC = [math]::Floor($keepC / 1GB) * 1GB           # 取整到 GB
            $dSize = $cPart.Size - $keepC
            Log ("方案计算: C 盘容量 {0} -> 建议保留 {1}, 分给 D {2}" -f (ToGB $cPart.Size), (ToGB $keepC), (ToGB $dSize))

            if ($dSize -lt 30GB) {
                $partMsg = "C 盘能腾出来的空间不足 30GB（系统限制最小只能缩到 $(ToGB $supported.SizeMin)），分盘意义不大，已跳过。" +
                           " 提示：可以在管理员命令行执行 powercfg /h off 关闭休眠文件后重试。"
                Log $partMsg 'Yellow'
            } else {
                $canPartition = $true
            }
        }
    }
}
catch {
    $partMsg = "磁盘检查出错：" + $_.Exception.Message
    Log $partMsg 'Red'
}

# ================================================================
#  第 2 步：分盘（需要确认）
# ================================================================
Title "第 2 步 / 共 5 步：分出 D 盘"

if ($canPartition) {
    Write-Host ""
    Write-Host "  即将执行的方案：" -ForegroundColor White
    Write-Host ("    C 盘  {0}   ->   {1}   （系统盘，装软件用）" -f (ToGB $cPart.Size), (ToGB $keepC)) -ForegroundColor White
    Write-Host ("    新建 D 盘             {0}   （放你自己的文件）" -f (ToGB $dSize)) -ForegroundColor White
    Write-Host ""
    Write-Host "  这个操作不会删除任何文件，但过程中请不要关机或断电。" -ForegroundColor Yellow
    Write-Host ""
    $ans = Read-Host "  确认分盘请输入 Y 再按回车（输入其他任意内容则跳过分盘）"

    if ($ans -match '^[Yy]$') {
        try {
            Log "正在收缩 C 盘 ..." 'Cyan'
            Resize-Partition -DriveLetter C -Size $keepC -ErrorAction Stop
            Start-Sleep -Seconds 3

            $free = (Get-Disk -Number $cPart.DiskNumber).LargestFreeExtent
            Log ("收缩完成，硬盘上最大的空闲空间: " + (ToGB $free))

            Log "正在创建 D 盘 ..." 'Cyan'
            New-Partition -DiskNumber $cPart.DiskNumber -UseMaximumSize -DriveLetter D -ErrorAction Stop | Out-Null
            Start-Sleep -Seconds 2

            Log "正在格式化 D 盘 ..." 'Cyan'
            Format-Volume -DriveLetter D -FileSystem NTFS -NewFileSystemLabel "数据" -Confirm:$false -ErrorAction Stop | Out-Null

            $dReady = $true
            Log ("D 盘创建成功！容量 " + (ToGB (Get-Volume -DriveLetter D).Size)) 'Green'
        }
        catch {
            Log ("分盘失败：" + $_.Exception.Message) 'Red'
            Log "别担心，C 盘数据是安全的。跳过分盘，继续后面的步骤。" 'Yellow'
        }
    } else {
        Log "已跳过分盘。" 'Yellow'
    }
}
elseif ($dReady) {
    Log "跳过分盘（已有 D 盘）。" 'Green'
}
else {
    Log ("跳过分盘。原因：" + $partMsg) 'Yellow'
}

# ================================================================
#  第 3 步：建文件夹
# ================================================================
Title "第 3 步 / 共 5 步：创建文件夹"

$folders = @('娱乐', '学习', '工具')
if ($dReady -or (Get-Volume -DriveLetter D -ErrorAction SilentlyContinue)) {
    foreach ($f in $folders) {
        $p = "D:\$f"
        if (Test-Path $p) { Log "已存在：$p" }
        else {
            New-Item -Path $p -ItemType Directory -Force | Out-Null
            Log "已创建：$p" 'Green'
        }
    }
} else {
    Log "没有 D 盘，改为在「此电脑 -> 文档」下创建这三个文件夹。" 'Yellow'
    $docs = [Environment]::GetFolderPath('MyDocuments')
    foreach ($f in $folders) {
        $p = Join-Path $docs $f
        if (-not (Test-Path $p)) { New-Item -Path $p -ItemType Directory -Force | Out-Null }
        Log "已创建：$p" 'Green'
    }
}

# ================================================================
#  第 4 步：把「文档 / 下载 / 图片」等默认位置搬到 D 盘
# ================================================================
Title "第 4 步 / 共 5 步：把默认保存位置改到 D 盘"

$USF = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders'
$SF  = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders'

# 刷新资源管理器，让改动立刻生效
function Invoke-ShellRefresh {
    try {
        if (-not ('Win32.Shell32' -as [type])) {
            Add-Type -Namespace Win32 -Name Shell32 -MemberDefinition @'
[DllImport("shell32.dll")]
public static extern void SHChangeNotify(int eventId, uint flags, IntPtr item1, IntPtr item2);
'@
        }
        [Win32.Shell32]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)
    } catch {}
}

# 把一个系统文件夹重定向到新位置，并搬走原有文件
function Move-KnownFolder {
    param([string]$Label, [string]$RegName, [string]$Target)

    $cur = (Get-ItemProperty -Path $USF -Name $RegName -ErrorAction SilentlyContinue).$RegName
    if (-not $cur) { $cur = (Get-ItemProperty -Path $SF -Name $RegName -ErrorAction SilentlyContinue).$RegName }
    if (-not $cur) { Log ("$Label ：读不到当前位置，跳过。") 'Yellow'; return 'skip' }

    $curExp = [Environment]::ExpandEnvironmentVariables($cur)

    if ($curExp -like '*OneDrive*') {
        Log ("$Label ：目前由 OneDrive 接管（$curExp），跳过。") 'Yellow'
        return 'onedrive'
    }
    if ($curExp -like 'D:\*') {
        Log ("$Label ：已经在 D 盘了，跳过。") 'Green'
        return 'done'
    }

    try {
        if (-not (Test-Path $Target)) { New-Item -Path $Target -ItemType Directory -Force | Out-Null }

        if (Test-Path $curExp) {
            Log ("$Label ：正在把文件从 $curExp 搬到 $Target ...") 'Cyan'
            & robocopy $curExp $Target /E /MOVE /R:1 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
            if ($LASTEXITCODE -ge 8) {
                Log ("$Label ：文件搬运失败（robocopy 代码 $LASTEXITCODE），保持原样不改注册表。") 'Red'
                return 'fail'
            }
        }

        New-ItemProperty -Path $USF -Name $RegName -Value $Target -PropertyType ExpandString -Force | Out-Null
        Set-ItemProperty  -Path $SF  -Name $RegName -Value $Target -Force -ErrorAction SilentlyContinue

        Log ("$Label ：已改到 $Target") 'Green'
        return 'ok'
    }
    catch {
        Log ("$Label ：出错 - " + $_.Exception.Message) 'Red'
        return 'fail'
    }
}

$redirected = @()
if (-not (Get-Volume -DriveLetter D -ErrorAction SilentlyContinue)) {
    Log "没有 D 盘，跳过这一步。" 'Yellow'
} else {
    Log ("当前用户：" + [Security.Principal.WindowsIdentity]::GetCurrent().Name)
    Write-Host ""
    Write-Host "  这一步会把「文档、下载、图片、音乐、视频」的默认保存位置" -ForegroundColor White
    Write-Host "  从 C 盘改到 D:\个人文件\ ，并把里面已有的文件一并搬过去。" -ForegroundColor White
    Write-Host ""
    Write-Host "  好处：以后浏览器下载的东西、聊天记录、作业，都会自动存到 D 盘，" -ForegroundColor White
    Write-Host "        C 盘不会越用越满。这是新电脑最值得做的一步设置。" -ForegroundColor White
    Write-Host ""
    $a = Read-Host "  执行请输入 Y 再回车（输入其他内容则跳过）"

    if ($a -match '^[Yy]$') {
        $kfList = @(
            @{ L='文档'; R='Personal';    T='D:\个人文件\文档' }
            @{ L='下载'; R='{374DE290-123F-4565-9164-39C4925E467B}'; T='D:\个人文件\下载' }
            @{ L='图片'; R='My Pictures'; T='D:\个人文件\图片' }
            @{ L='音乐'; R='My Music';    T='D:\个人文件\音乐' }
            @{ L='视频'; R='My Video';    T='D:\个人文件\视频' }
        )

        $odHit = $false
        foreach ($k in $kfList) {
            $r = Move-KnownFolder -Label $k.L -RegName $k.R -Target $k.T
            if ($r -eq 'ok')       { $redirected += $k.L }
            if ($r -eq 'onedrive') { $odHit = $true }
        }

        if ($odHit) {
            Write-Host ""
            Write-Host "  注意：有文件夹正被 OneDrive 同步接管，已跳过它们。" -ForegroundColor Yellow
            Write-Host "  如果想改到 D 盘，先打开 OneDrive 设置 -> 同步和备份 -> 管理备份，" -ForegroundColor Yellow
            Write-Host "  把文件夹备份全部关掉，然后重新运行本脚本。" -ForegroundColor Yellow
            Write-Host ""
        }

        # 桌面单独问，因为改桌面比较容易出怪问题
        Write-Host ""
        $a2 = Read-Host "  要不要把「桌面」也改到 D 盘？（不太推荐，要改就输入 Y）"
        if ($a2 -match '^[Yy]$') {
            $r = Move-KnownFolder -Label '桌面' -RegName 'Desktop' -Target 'D:\个人文件\桌面'
            if ($r -eq 'ok') { $redirected += '桌面' }
        } else {
            Log "桌面保持在 C 盘不动。" 'Gray'
        }

        if ($redirected.Count -gt 0) {
            Invoke-ShellRefresh
            Log "正在重启资源管理器让改动生效 ..." 'Cyan'
            try {
                Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
                Start-Sleep -Seconds 3
                if (-not (Get-Process -Name explorer -ErrorAction SilentlyContinue)) { Start-Process explorer.exe }
            } catch {}
        }
    } else {
        Log "已跳过默认位置修改。" 'Yellow'
    }
}

# ================================================================
#  第 5 步：安装软件
# ================================================================
Title "第 5 步 / 共 5 步：安装常用软件"

$apps = @(
    [pscustomobject]@{ Name='微信';     Id='Tencent.WeChat';         Url='https://weixin.qq.com/' }
    [pscustomobject]@{ Name='QQ';       Id='Tencent.QQ';             Url='https://im.qq.com/pcqq/' }
    [pscustomobject]@{ Name='腾讯会议'; Id='Tencent.TencentMeeting'; Url='https://meeting.tencent.com/download/' }
    [pscustomobject]@{ Name='腾讯视频'; Id='Tencent.TencentVideo';   Url='https://v.qq.com/download.html' }
    [pscustomobject]@{ Name='WPS Office'; Id='Kingsoft.WPSOffice';   Url='https://www.wps.cn/' }
)

$ok     = @()
$failed = @()

$winget = Get-Command winget -ErrorAction SilentlyContinue
if (-not $winget) {
    Log "系统里没有 winget（应用安装程序），无法自动装软件。" 'Yellow'
    Log "解决办法：打开「Microsoft Store」，搜索「应用安装程序」并安装，然后重新运行本脚本。" 'Yellow'
    $failed = $apps
} else {
    Log "正在更新软件源，请稍候 ..." 'Cyan'
    & winget source update --disable-interactivity 2>&1 | Out-Null

    foreach ($app in $apps) {
        Log ("正在安装 " + $app.Name + " ...") 'Cyan'

        # 已装过就跳过
        & winget list --id $app.Id -e --accept-source-agreements 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Log ($app.Name + " 已经安装过了，跳过。") 'Green'
            $ok += $app.Name
            continue
        }

        $out = & winget install --id $app.Id -e --silent `
                   --accept-package-agreements --accept-source-agreements 2>&1
        $out | Out-String | ForEach-Object { Add-Content -Path $LogFile -Value $_ -Encoding UTF8 }

        # 用 winget list 复查，比看返回码可靠
        & winget list --id $app.Id -e 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Log ($app.Name + " 安装成功。") 'Green'
            $ok += $app.Name
        } else {
            Log ($app.Name + " 自动安装失败，稍后会打开官网让你手动下载。") 'Yellow'
            $failed += $app
        }
    }
}

# ================================================================
#  汇总
# ================================================================
Title "全部完成"

Write-Host ""
if ($redirected.Count -gt 0) { Write-Host ("  已改到 D 盘：" + ($redirected -join '、') + "  （建议重启一次电脑）") -ForegroundColor Green }
if ($ok.Count -gt 0)     { Write-Host ("  安装成功：" + ($ok -join '、'))            -ForegroundColor Green }
if ($failed.Count -gt 0) { Write-Host ("  需要手动装：" + ($failed.Name -join '、')) -ForegroundColor Yellow }

$dNow = Get-Volume -DriveLetter D -ErrorAction SilentlyContinue
if ($dNow) {
    Write-Host ("  D 盘：{0}，里面已建好 娱乐 / 学习 / 工具 三个文件夹" -f (ToGB $dNow.Size)) -ForegroundColor Green
}
Write-Host ""
Write-Host ("  详细日志：" + $LogFile) -ForegroundColor Gray
Write-Host ""

if ($failed.Count -gt 0) {
    $a = Read-Host "  按回车键打开需要手动安装的软件官网（不需要就输入 N 再回车）"
    if ($a -notmatch '^[Nn]$') {
        foreach ($f in $failed) { Start-Process $f.Url; Start-Sleep -Milliseconds 800 }
    }
}

Read-Host "  一切就绪，按回车键关闭窗口"
